import java.io.IOException;
class Main {
    public static void main(String[] args) throws IOException {
        Cliente cliente1 = new Cliente();
        Locadora locadora = new Locadora();
        locadora.Menu(locadora, cliente1);
    }

}
