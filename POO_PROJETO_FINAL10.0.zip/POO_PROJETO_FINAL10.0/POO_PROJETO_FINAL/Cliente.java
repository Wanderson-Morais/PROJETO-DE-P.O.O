import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

class Cliente {
  private String nome;
  private double saldo;
  protected int id;
  private String cpf;
  private String Email;
  Scanner sc = new Scanner(System.in);

  public double getSaldo() {
      return this.saldo;
  }
  public void setSaldo(double saldo){
    this.saldo = saldo;
  }

  public String getEmail() {
    return this.Email;
  }

  public void setEmail(String email) {
    this.Email = email;
  }
  public int getid() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getNome() {
    return this.nome;
  }

  public void setNome(String n) {
    this.nome = n;
  }

  public String getCpf() {
    return this.cpf;
  }

  public void setCpf(String cpf) {
    this.cpf = cpf;
  }

  public int Cadastro(Cliente cliente) throws IOException {
    System.out.println("\nCadastrar clientes\n");
    System.out.println("Nome: ");
    String a = sc.nextLine();
    cliente.setNome(a);

    cliente.setSaldo(1000);
  
    System.out.println("Email:");
    String c = sc.nextLine();
    cliente.setEmail(c);
    
    System.out.println("CPF:");
    String b = sc.nextLine();
    cliente.setCpf(b);

    System.out.println("Cliente cadastrado com sucesso!\n\n");
    int condicao = 1;

    FileWriter escritor = new FileWriter(
    "/Users/USUARIO/Desktop/Downloads/POO_PROJETO_FINAL10.0/POO_PROJETO_FINAL/clientes.txt", true);                                                                      
    escritor.write("Nome: " + this.nome + "\nCPF: " + this.cpf + "\nEmail: " + this.Email + "\n\n");
    escritor.close();
    return condicao;
  }

}
