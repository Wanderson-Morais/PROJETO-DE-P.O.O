import java.util.Scanner;
import java.io.IOException;
import java.io.File;
//import java.io.FileReader;
//import org.omg.PortableInterceptor.LOCATION_FORWARD;
//import java.io.FileWriter;

public class Locadora extends Filmes implements Arquivo, Funcionario {
  protected int quantClientes = 0;
  protected int numfilmes = 0;
  protected double valorfilmes= 10;
  Scanner sc = new Scanner(System.in);

  public void menuFilmes(Locadora locadora, Cliente cliente, int mostrar) throws IOException {
    int stop = 1;
    String local;
    while (stop == 1) {
      System.out.println("-----Mostrar Filmes-----");
      System.out
          .println("\n[1] - Aventura\n[2] - Musical\n[3] - Terror\n[4] - Romance\n[5] - Filmes adultos\n[6] - Voltar");
      int op = sc.nextInt();
      switch (op) {
        case 1:
        local = ("POO_PROJETO_FINAL/Aventura.txt");
        if(mostrar == 0){//mostrar
          Arquivo.lerArquivo(local);
        }else if(mostrar == 1){//buscar
          buscarfilme(local);
          break;
        }else{
          cadastrarfilme(local);
          System.out.println("Filme cadastrado com sucesso!\n\n");
        }
          break;
        case 2:
        local = ("POO_PROJETO_FINAL/Musical.txt");
        if(mostrar == 0){//mostrar
          Arquivo.lerArquivo(local);
        }else if(mostrar == 1){//buscar
          buscarfilme(local);
          break;
        }else{
          cadastrarfilme(local);
          System.out.println("Filme cadastrado com sucesso!\n\n");
        }
          break;
        case 3:
        local = ("POO_PROJETO_FINAL/Terror.txt");
        if(mostrar == 0){//mostrar
          Arquivo.lerArquivo(local);
        }else if(mostrar == 1){//buscar
          buscarfilme(local);
          break;
        }else{
          cadastrarfilme(local);
          System.out.println("Filme cadastrado com sucesso!\n\n");
        }
          break;
        case 4:
        local = ("POO_PROJETO_FINAL/Romance.txt");
        if(mostrar == 0){//mostrar
          Arquivo.lerArquivo(local);
        }else if(mostrar == 1){//buscar
          buscarfilme(local);
          break;
        }else{
          cadastrarfilme(local);
          System.out.println("Filme cadastrado com sucesso!\n\n");
        }
        break;
        case 5:
        local = ("POO_PROJETO_FINAL/Filmes_adultos.txt");
        if(mostrar == 0){//mostrar
          Arquivo.lerArquivo(local);
        }else if(mostrar == 1){//buscar
          buscarfilme(local);
          break;
        }else{
          cadastrarfilme(local);
          System.out.println("Filme cadastrado com sucesso!\n\n");
        }
          break;
        case 6://voltar
          stop=0;
          break;
      }
    }
  }
  
  public void Alugarfilme(Cliente cliente){
    double a;
    a = cliente.getSaldo() - this.valorfilmes;
    cliente.setSaldo(a);
  }

  public void Menucliente(Locadora locadora, Cliente cliente) throws IOException {
    int stop = 1;
    int mostrar;
    int condicao = 0;
    int quer=0;
    while (stop == 1) {
      System.out.println("-----MENU CLIENTE-----");
      System.out
          .println("\n[1] - Cadastrar conta\n[2] - Mostrar Filmes\n[3] - Informa��es clientes\n[4] - Alugar\n[5] - Voltar\nEscolha a op��o: ");
      int op = sc.nextInt();
      switch (op) {
        case 1:// cadastrar conta
          condicao = Cadastro(cliente);
          stop = 1;
          break;
        case 2:// Mostrar filmes
          mostrar = 0;
          menuFilmes(locadora, cliente, mostrar);
          break;
        case 3:
          if(condicao==1){
            System.out.println("Nome: "+cliente.getNome()+"\n");
            System.out.println("Saldo: "+cliente.getSaldo()+"\n");
            System.out.println("Cpf: "+cliente.getCpf()+"\n");
            System.out.println("Email: "+cliente.getEmail()+"\n");

          }else {
            System.out.println("Voc� n�o possui um cadastro na locadora Ragnarok");
          }
 
          break;
        case 4: // Alugar //buscar filmes por nome e verificar existencia
          if(condicao==1){
            mostrar = 1;
            menuFilmes(locadora, cliente, mostrar);
            quer=desejacomprar(quer);
            if(quer==1){
              Alugarfilme(cliente);
            }
          }else{
          System.out.println("Voc� n�o possui um cadastro na locadora Ragnarok");
          }
          break;
        case 5: // Voltar
          stop=0;
        break;
      }
    }
  }

  public void MenuFuncionario(Locadora locadora, Cliente cliente) throws IOException {
    int stop = 1;
    int mostrar;
    String local;
    while (stop == 1) {
      System.out.println("-----MENU FUNCIONARIO-----");
      System.out.println(
          "\n[1] - Mostrar clientes\n[2] - Mostrar Funcionarios\n[3] - Cadastrar Filme\n[4] - Mostrar Filmes\n[5] - Voltar\n\nEscolha a opcao: ");
      int op = sc.nextInt();
      switch (op) {
        case 1:
          local = ("POO_PROJETO_FINAL/clientes.txt");
          File file = new File(local);
          String path = file.getPath();
          Arquivo.lerArquivo(path);
          break;
        case 2:
          local = ("POO_PROJETO_FINAL/Funcionarios.txt");
          Arquivo.lerArquivo(local);
          break;
        case 3: // cadastrar filmes
        mostrar=2;
          menuFilmes(locadora, cliente, mostrar);
          break;
        case 4:// Mostrar filmes
          mostrar=0;
          menuFilmes(locadora, cliente, mostrar);
          break;
        case 5:
          stop=0;
          break;
      }
    }
  }

  public void Menu(Locadora locadora, Cliente cliente) throws IOException {
    int stop=1;
    while(stop==1){
    System.out.println("----- LOCADORA RAGNAROK-----");
    System.out.println("\n[1] - Entrar como clinte\n[2] - Entrar como funcionario\n[3] - Sair\n\nEscolha a opcao: ");
    int op0 = sc.nextInt();
    switch (op0) {
      case 1:
        Menucliente(locadora, cliente);
        stop=1;
        break;
      case 2:
        Funcionario.Comparandonesenhas(locadora, cliente);
        MenuFuncionario(locadora, cliente);
        stop=1;
        break;
      case 3:
        stop=0;
        break;
    }
  }
 }
}