import java.util.Scanner;
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
import java.io.IOException;

interface Funcionario {
    static String senhadeacesso = "Ragnarok123";

    public static void mostrarFuncioarios() {

    }

    public static void Comparandonesenhas(Locadora locadora, Cliente cliente) throws IOException {
        Scanner senha = new Scanner(System.in);

        System.out.println("Digite a senha: ");
        String pass = senha.next();

        if (pass.equals(senhadeacesso)) {
            System.out.println("\nAcesso liberado");
        } else {
            System.out.println("\nSenha incorreta\n");
            locadora.Menu(locadora, cliente);
        }
    }
}
