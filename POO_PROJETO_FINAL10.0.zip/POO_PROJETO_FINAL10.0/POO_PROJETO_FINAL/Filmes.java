import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;

public class Filmes extends Cliente{
  protected String Titulo;
  protected String Ano;
  protected String codigo;
  static Scanner sc = new Scanner(System.in);

  public String getTitulo() {
    return this.Titulo;
  }

  public void setTitulo(String titulo) {
    this.Titulo = titulo;
  }

  public String getAno() {
      return this.Ano;
  }
  public void setAno(String ano) {
      this.Ano = ano;
  }

  public String getCodigo() {
      return this.codigo;
  }
  public void setCodigo(String codigo) {
      this.codigo= codigo;
  }
  
  public void buscarfilme(String local) throws FileNotFoundException{
    System.out.printf("Informe o codigo do filme:\n");
    String n= "Codigo: "+ sc.nextLine();
    System.out.println(getValor(n, local));
    }
    
    public int desejacomprar(int quer){
      System.out.println("Voc� deseja comprar esse filme?[s/n]: ");
      String deseja = sc.nextLine();
      if(deseja.equals("s")){
        quer = 1;
      }
      else{

      }
      return quer;
    }
    private String getValor(String n, String local) throws FileNotFoundException {
      String valor = "";
      Scanner in = new Scanner(new FileReader(local));
      while (in.hasNextLine()) {
        String word = in.nextLine();
        String line = in.nextLine();
        String[] palavra = word.split("\0");
        String[] linha = line.split("\0");
        if(palavra[0].equalsIgnoreCase(n)) {
          valor = linha[0];
          break;
        } else {
          valor = "erro";
          }
        }
        return valor;
    }
   

  public void cadastrarfilme(String local) throws IOException {
    System.out.println("\nCadastrar filme\n");
    System.out.println("codigo: ");
    String a= sc.nextLine();
    System.out.println("Nome: ");
    String b = sc.nextLine();
    System.out.println("Ano: ");
    String c = sc.nextLine();
    setCodigo(a);
    setTitulo(b);
    setAno(c);
    
    FileWriter escritor = new FileWriter(local, true);
    escritor.write("\n\ncodigo: "+getCodigo()+"\n"+getTitulo()+"\t("+getAno()+")");
    escritor.close();

  }

}