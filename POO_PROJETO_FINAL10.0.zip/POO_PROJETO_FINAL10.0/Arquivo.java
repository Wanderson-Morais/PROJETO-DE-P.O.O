import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

interface Arquivo {

    public static void lerArquivo(String file) throws FileNotFoundException {
        File file0 = new File(file);
        Scanner scan0 = new Scanner(file0);
        while (scan0.hasNextLine()) {
            System.out.println(scan0.nextLine());
        }
    }
}
