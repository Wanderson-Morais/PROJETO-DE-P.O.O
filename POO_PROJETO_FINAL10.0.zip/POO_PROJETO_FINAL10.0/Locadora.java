import java.util.Scanner;
import java.io.IOException;

public class Locadora extends Filmes implements Arquivo, Funcionario {
  protected int quantClientes = 0;
  protected int numfilmes = 0;
  protected double valorfilmes= 10;
  Scanner sc = new Scanner(System.in);
//-----------------------------------------------------------------------------------------------------
  public int menuFilmes(Locadora locadora, Cliente cliente, int mostrar) throws IOException {
    int stop = 1;
    int quer=0;
    String arquivotxt;
    while (stop == 1) {
      System.out.println("-----Mostrar Filmes-----");
      System.out
          .println("\n[1] - Aventura\n[2] - Musical\n[3] - Terror\n[4] - Romance\n[5] - Filmes adultos\n[6] - Voltar");
      int op = sc.nextInt();
      switch (op) {
        case 1:
        arquivotxt = ("Aventura.txt");
        System.out.println("local = "+arquivotxt);
        if(mostrar == 0){//mostrar
          Arquivo.lerArquivo(arquivotxt);
        }else if(mostrar == 1){//buscar
          quer= buscarfilme(arquivotxt);
          stop = 0;
          break;
        }else{
          cadastrarfilme(arquivotxt);
          System.out.println("Filme cadastrado com sucesso!\n\n");
        }
          break;
        case 2:
        arquivotxt = ("Musical.txt");
        System.out.println("local = "+arquivotxt);
        if(mostrar == 0){//mostrar
          Arquivo.lerArquivo(arquivotxt);
        }else if(mostrar == 1){//buscar
          quer = buscarfilme(arquivotxt);
          stop = 0;
          break;
        }else{
          cadastrarfilme(arquivotxt);
          System.out.println("Filme cadastrado com sucesso!\n\n");
        }
          break;
        case 3:
        arquivotxt = ("Terror.txt");
        System.out.println("local = "+arquivotxt);
        if(mostrar == 0){//mostrar
          Arquivo.lerArquivo(arquivotxt);
        }else if(mostrar == 1){//buscar
          quer = buscarfilme(arquivotxt);
          stop = 0;
          break;
        }else{
          cadastrarfilme(arquivotxt);
          System.out.println("Filme cadastrado com sucesso!\n\n");
        }
          break;
        case 4:
        arquivotxt = ("Romance.txt");
        System.out.println("local = "+arquivotxt);
        if(mostrar == 0){//mostrar
          Arquivo.lerArquivo(arquivotxt);
        }else if(mostrar == 1){//buscar
          quer = buscarfilme(arquivotxt);
          stop = 0;
          break;
        }else{
          cadastrarfilme(arquivotxt);
          System.out.println("Filme cadastrado com sucesso!\n\n");
        }
        break;
        case 5:
        arquivotxt = ("Filmes_adultos.txt");
        System.out.println("local ="+ arquivotxt);
        if(mostrar == 0){//mostrar
          Arquivo.lerArquivo(arquivotxt);
        }else if(mostrar == 1){//buscar
          quer = buscarfilme(arquivotxt);
          stop = 0;
          break;
        }else{
          cadastrarfilme(arquivotxt);
          System.out.println("Filme cadastrado com sucesso!\n\n");
        }
          break;
        case 6://voltar
          stop=0;
          break;
      }
    }
    return quer;
  }
  
  public void Alugarfilme(Cliente cliente){
    double a;
    a = cliente.getSaldo() - this.valorfilmes;
    cliente.setSaldo(a);
  }
//------------------------------------------------------------------------------------------
  public void Menucliente(Locadora locadora, Cliente cliente) throws IOException {
    int stop = 1;
    int mostrar;
    int condicao = 0;
    int quer=0;
    while (stop == 1) {
      System.out.println("-----MENU CLIENTE-----");
      System.out
          .println("\n[1] - Cadastrar conta\n[2] - Mostrar Filmes\n[3] - Informacoes clientes\n[4] - Alugar\n[5] - Voltar\nEscolha a opcao: ");
      int op = sc.nextInt();
      switch (op) {
        case 1:// cadastrar conta
          condicao = Cadastro(cliente);
          stop = 1;
          break;
        case 2:// Mostrar filmes
          mostrar = 0;
          menuFilmes(locadora, cliente, mostrar);
          break;
        case 3:
          if(condicao==1){
            System.out.println("Nome: "+cliente.getNome()+"\n");
            System.out.println("Saldo: "+cliente.getSaldo()+"\n");
            System.out.println("Cpf: "+cliente.getCpf()+"\n");
            System.out.println("Email: "+cliente.getEmail()+"\n");

          }else {
            System.out.println("Voce nao possui um cadastro na locadora Ragnarok");
          }
 
          break;
        case 4: // Alugar //buscar filmes por nome e verificar existencia
          if(condicao==1){
            mostrar = 1;
            quer = menuFilmes(locadora, cliente, mostrar);
            if(quer==1){
              Alugarfilme(cliente);
              System.out.println("Compra concluida com sucesso!!!!");
            }
          }else{
          System.out.println("Voce nao possui um cadastro na locadora Ragnarok");
          }
          break;
        case 5: // Voltar
          stop=0;
        break;
      }
    }
  }
//----------------------------------------------------------------------------------------------
  public void MenuFuncionario(Locadora locadora, Cliente cliente) throws IOException {
    int stop = 1;
    int mostrar;
    String arquivotxt;
    while (stop == 1) {
      System.out.println("-----MENU FUNCIONARIO-----");
      System.out.println(
          "\n[1] - Mostrar clientes\n[2] - Mostrar Funcionarios\n[3] - Cadastrar Filme\n[4] - Mostrar Filmes\n[5] - Voltar\n\nEscolha a opcao: ");
      int op = sc.nextInt();
      switch (op) {
        case 1:
          arquivotxt = "Clientes.txt";
          System.out.println("local = "+arquivotxt);
          Arquivo.lerArquivo(arquivotxt);
          break;
        case 2:
          arquivotxt = "Funcionarios.txt";
          System.out.println("local = "+arquivotxt);
          Arquivo.lerArquivo(arquivotxt);
          break;
        case 3: // cadastrar filmes
        mostrar=2;
          menuFilmes(locadora, cliente, mostrar);
          break;
        case 4:// Mostrar filmes
          mostrar=0;
          menuFilmes(locadora, cliente, mostrar);
          break;
        case 5:
          stop=0;
          break;
      }
    }
  }
//----------------------------------------------------------------------------------
  public void Menu(Locadora locadora, Cliente cliente) throws IOException {
    int stop=1;
    while(stop==1){
    System.out.println("----- LOCADORA RAGNAROK-----");
    System.out.println("\n[1] - Entrar como clinte\n[2] - Entrar como funcionario\n[3] - Sair\n\nEscolha a opcao: ");
    int op0 = sc.nextInt();
    switch (op0) {
      case 1:
        Menucliente(locadora, cliente);
        stop=1;
        break;
      case 2:
        Funcionario.Comparandonesenhas(locadora, cliente);
        MenuFuncionario(locadora, cliente);
        stop=1;
        break;
      case 3:
        stop=0;
        break;
    }
  }
 }
}